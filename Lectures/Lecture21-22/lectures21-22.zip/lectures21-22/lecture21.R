library(tidyverse)
library(stargazer)

# Load data
data <- read.csv("caschool.csv")
