library(tidyverse)
library(stargazer)

# Load data
data <- read.csv("acs2019.csv")
